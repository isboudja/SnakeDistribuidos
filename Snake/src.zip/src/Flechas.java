import java.io.Serializable;

public enum Flechas implements Serializable{
    ARRIBA, ABAJO, IZQUIERDA, DERECHA
}
